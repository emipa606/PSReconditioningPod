﻿using RimWorld;
using System;
using System.Collections.Generic;
using Verse;

namespace PS_ReconPod
{
    // Token: 0x020007C8 RID: 1992
    public class PS_Alert_ConditioningFailing: Alert_Critical
    {
        // Token: 0x06002C2E RID: 11310 RVA: 0x0014B3CC File Offset: 0x001497CC
        public PS_Alert_ConditioningFailing()
        {
            this.defaultLabel = "PS_AlertConditioningFailingLab".Translate();
            this.defaultExplanation = "PS_AlertConditioningFailingDes".Translate();
            this.defaultPriority = AlertPriority.Critical;
        }

        // Token: 0x170006DB RID: 1755
        // (get) Token: 0x06002C2F RID: 11311 RVA: 0x0014B3FC File Offset: 0x001497FC
        private IEnumerable<Pawn> ConditionedAndSlipping
        {
            get
            {
                foreach (Pawn p in PawnsFinder.AllMapsCaravansAndTravelingTransportPods_Alive_FreeColonistsAndPrisoners_NoCryptosleep)
                {
                    if (PS_ConditioningHelper.IsReconditioned(p))
                    {
                        var conditionLevel = PS_ConditioningHelper.GetCurrentNeedLevel(p);
                        if(conditionLevel <= 0.25f)
                            yield return p;
                    }
                }
                yield break;
            }
        }

        // Token: 0x06002C30 RID: 11312 RVA: 0x0014B418 File Offset: 0x00149818
        public override AlertReport GetReport()
        {
            return AlertReport.CulpritsAre(this.ConditionedAndSlipping);
        }
    }
}
