﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace PS_ReconPod
{
    public enum ConditioningCategory
    {
        UNSET = -1,
        Slipping = 0,
        Weakened = 1,
        Strong = 2,
        Fresh = 3
    }
}
